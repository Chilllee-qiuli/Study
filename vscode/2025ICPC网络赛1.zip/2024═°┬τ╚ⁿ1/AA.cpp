#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    map<string,int> a; //AC数
    map<string,int> b; //unknown数
    map<string,map<string,int>> c;//是否过题
    map<string,map<string,int    
    return 0;
}